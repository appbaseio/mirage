export interface Config {
	url: string;
	appname: string;
	username: string;
	password: string;
	host: string;
}