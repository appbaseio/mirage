import { Component} from "@angular/core";
@Component({
	selector: 'my-app',
	template: 'dsjhfer jehrfjr'
})

export class AppComponent {
	constructor() {
		alert(1);
	}
}
